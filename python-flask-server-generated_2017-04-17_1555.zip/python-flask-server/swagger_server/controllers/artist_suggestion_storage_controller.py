import connexion
from swagger_server.models.artist_list import ArtistList
from swagger_server.models.artist_not_found import ArtistNotFound
from swagger_server.models.default_error_response import DefaultErrorResponse
from swagger_server.models.invalid_syntax import InvalidSyntax
from datetime import date, datetime
from typing import List, Dict
from six import iteritems
from ..util import deserialize_date, deserialize_datetime


def add_artist(artist_name, artist_conn=None):
    """
    Add artist to database
    
    :param artist_name: Artist to add
    :type artist_name: str
    :param artist_conn: Added artist&#39;s connections
    :type artist_conn: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        artist_conn = ArtistList.from_dict(connexion.request.get_json())
    return 'do some magic!'


def delete_artist(artist_name):
    """
    Delete artist from database
    
    :param artist_name: Artist to delete
    :type artist_name: str

    :rtype: None
    """
    return 'do some magic!'


def get_artist(artist_name):
    """
    Get stored similar artists list
    
    :param artist_name: Requested artist
    :type artist_name: str

    :rtype: ArtistList
    """
    return 'do some magic!'


def update_artist(artist_name, artist_conn):
    """
    Update artist in database
    
    :param artist_name: Artist to add
    :type artist_name: str
    :param artist_conn: Updated artist&#39;s connections
    :type artist_conn: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        artist_conn = ArtistList.from_dict(connexion.request.get_json())
    return 'do some magic!'
